package tracer.ui;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import tracer.model.IncomeTransaction;
import tracer.model.StockTransaction;
import tracer.model.TracerSystem;

import javax.swing.*;
import java.util.Map;

/**
 * Represents a JFrame that displays asset allocation information.
 */
public class AssetAllocationFrame extends JFrame {

    private TracerSystem tracerSystem;

    /**
     * Constructs an AssetAllocationFrame with the given TracerSystem.
     *
     * @param tracerSystem the TracerSystem to display asset allocation information for
     */
    public AssetAllocationFrame(TracerSystem tracerSystem) {
        this.tracerSystem = tracerSystem;

        JSplitPane splitPane = new JSplitPane();
        add(splitPane);

        splitPane.setLeftComponent(createTotalAssetChartPanel());
        splitPane.setRightComponent(createStockAssetChartPanel());
        splitPane.setContinuousLayout(true);


        setTitle("Asset Allocation");
        pack();
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
        splitPane.setDividerLocation(0.5);

    }

    /**
     * Creates a ChartPanel displaying the total asset allocation.
     *
     * @return the ChartPanel displaying the total asset allocation
     */
    private ChartPanel createTotalAssetChartPanel() {
        DefaultPieDataset<String> dataset = new DefaultPieDataset<>();
        dataset.setValue("Stock", tracerSystem.totalStockPrice());
        dataset.setValue("Cash", tracerSystem.netCash());

        JFreeChart chart = ChartFactory.createPieChart("Total AssetAllocation", dataset);
        return new ChartPanel(chart);
    }


    /**
     * Creates a ChartPanel displaying the stock asset allocation.
     *
     * @return the ChartPanel displaying the stock asset allocation
     */
    private ChartPanel createStockAssetChartPanel() {
        DefaultPieDataset<String> dataset = new DefaultPieDataset<>();

        Map<String, Double> stockTotals = tracerSystem.getStockTotalPrices();
        for (Map.Entry<String, Double> entry : stockTotals.entrySet()) {
            dataset.setValue(entry.getKey(), entry.getValue());
        }

        JFreeChart chart = ChartFactory.createPieChart("Stock Asset Allocation", dataset);
        return new ChartPanel(chart);
    }


}
